package com.chris.apachekafka.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.chris.apachekafka.storage.MessageStorage;

@Service
public class KafkaConsumer {
	private static final Logger log = LoggerFactory.getLogger(KafkaConsumer.class);

	@Autowired
	MessageStorage storage;
	
@KafkaListener(topics="${jsa.kafka.topic}")
public void processMessage(String message) throws Exception {
		log.info("received content = '{}'", message);
		try {
			int num = new Integer(message).intValue();
			if(num % 2 == 0) {
				throw new Exception("The number passed is EVEN : ");
			}else {
				log.info("The odd value : " + num);
			}
			
			}catch(Exception e) {
				log.error("Error message:  " + e.getMessage());
				throw new Exception(e.getMessage());
			}

		storage.put(message);
    }
}
